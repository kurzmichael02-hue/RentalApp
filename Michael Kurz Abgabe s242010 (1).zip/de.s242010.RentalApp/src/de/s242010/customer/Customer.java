package de.s242010.customer;

public class Customer {

	private static int idCounter = 1;
	private final int id;

	private String name;
	private String street;
	private String zipcode;
	private String city;
	private String country;
	private String email;

	public Customer(String name, String street, String zipcode, String city, String country, String email) {
		this.id = idCounter++;
		this.name = name;
		this.street = street;
		this.zipcode = zipcode;
		this.city = city;
		this.country = country;
		this.email = email;
	}

	// Getter
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getStreet() {
		return street;
	}

	public String getZipcode() {
		return zipcode;
	}

	public String getCity() {
		return city;
	}

	public String getCountry() {
		return country;
	}

	public String getEmail() {
		return email;
	}

	// Setter
	public void setName(String name) {
		this.name = name;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
	    return "Kunde: " + getName() + "\n" +
	           "Email: " + getEmail() + "\n" +
	           "Adaresse: " + getStreet() + ", " + getZipcode() + " " + getCity() + ", " + getCountry() + "\n" +
	           "Kunden-ID: " + getId();
	}

}