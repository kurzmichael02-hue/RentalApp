package de.s242010.vehicle;
import java.util.Comparator;

public class Vehiclemanucomp implements Comparator<Rentable> {
	public int compare(Rentable a, Rentable b) {
		
		if (a instanceof Vehicle && b instanceof Vehicle) {
			return ((Vehicle) a).getManufacturer().compareTo(((Vehicle) b).getManufacturer());
		}
		return 0;
	}
}
