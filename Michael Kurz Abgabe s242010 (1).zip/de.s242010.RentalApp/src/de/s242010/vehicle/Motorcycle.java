package de.s242010.vehicle;

public class Motorcycle extends Vehicle {
	private String bikeType;
	private double bikeBoost; // 0 -100 km/h in sek.
	
	public Motorcycle(double value, String description, String vin, String licensePlate, int mileage, String manufacturer, String model, String fuelType, int power, int countCylinders,
            String bikeType, double bikeBoost)
	{
		super(value, description, vin, licensePlate, mileage, manufacturer, model, fuelType, power, countCylinders);
		this.bikeType = bikeType;
		this.bikeBoost = bikeBoost;
	}
		//Getter
		public String getBikeType() {
			return bikeType;
		}
		public double getBikeBoost() {
			return bikeBoost;
		}
		
		//Setter
		public void setBikeType (String bikeType) {
			this.bikeType = bikeType;
		}
		public void setBikeBoost(double bikeBoost) {
			this.bikeBoost = bikeBoost;
		}
		
		public String toString() {
		    return "Fahrzeugtyp: Mottorrad\n" +
		    		"VIN: " + getVin() + "\n" +
		           "Hersteller: " + getManufacturer() + "\n" +
		           "Modell: " + getModel() + "\n" +
		           "Typ: " + getBikeType() + "\n" +
		           "Beschleunigung (0-100 km/h): " + getBikeBoost() + " s\n" +
		           "Kennzeichen: " + getLicensePlate() + "\n" +
		           "Kilometerstand: " + getMileage() + " km\n" +
		           "Wert: " + getValue() + " Euro\n" +
		           "Verliehen: " + isRented();
		}

}