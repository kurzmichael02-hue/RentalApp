package de.s242010.vehicle;
import java.util.Comparator;

public class VehicleRentalStatusComp implements Comparator<Rentable> {
    public int compare(Rentable a, Rentable b) {
        return Boolean.compare(a.isRented(), b.isRented());
    }
}
