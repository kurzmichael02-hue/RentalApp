package de.s242010.vehicle;

public class ElectricCar extends Car{
	
	private double chargingpower; // in kW
	private double batterycapacity; // in kWh
	
	
	public ElectricCar(double value, String description, String vin, String licensePlate, int mileage, String manufacturer, String model, String fuelType, int power, int countCylinders,
            double batterycapacity, double chargingpower)
	{
		super(value, description, vin, licensePlate, mileage, manufacturer, model, fuelType, power, countCylinders);
		
		this.batterycapacity = batterycapacity;
		this.chargingpower = chargingpower;
		
		
	}
	
	
	//Getter
	
	public double getChargingpower () {
	return chargingpower;
	}
	public double getBatterycapacity() {
		return batterycapacity;
	}
	
	
	//Setter
	public void setBatterycapacity(double batterycapacity) {
		this.batterycapacity = batterycapacity;
	}
	public void setChargingpower(double chargingpower) {
		this.chargingpower = chargingpower;
	}
	
	public String toString() {
	    return "Fahrzeugtyp: Elektroauto\n" +
	    		"VIN: " + getVin() + "\n" +
	           "Hersteller: " + getManufacturer() + "\n" +
	           "Modell: " + getModel() + "\n" +
	           "Leistung: " + getPower() + " PS\n" +
	           "Batteriekapazität: " + getBatterycapacity() + " kWh\n" +
	           "Ladeleistung: " + getChargingpower() + " kW\n" +
	           "Kennzeichen: " + getLicensePlate() + "\n" +
	           "Kilometerstand: " + getMileage() + " km\n" +
	           "Wert: " + getValue() + " Euro\n" +
	           "Verliehen: " + isRented();
	}

}