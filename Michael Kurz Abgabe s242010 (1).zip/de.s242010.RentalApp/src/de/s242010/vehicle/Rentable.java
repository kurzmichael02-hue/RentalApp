package de.s242010.vehicle;

import de.s242010.customer.Customer;

public abstract class Rentable
	{
	private final int id;
	private static int idCounter = 1;
	private boolean isRented;
	private double value;
	private String description;
	private Customer customer;
	
	public Rentable(String description, double value) 
	{
		this.id = idCounter++;
		this.description = description;
		this.isRented = false;
		this.value = value;
		this.customer = null;
	}
	

	// Setter
	public void setDescription (String description) {
		this.description = description;
	}
	public void setRented (boolean rented) {
		this.isRented = rented;
	}
	public void setValue ( double value) {
		this.value = value;
	}
	public void setCustomer (Customer customer) {
		this.customer = customer;
	}
	
	
	// Getter
	public int getID() {
		return id;
	}
	public String getDescription () {
		return description;
	}
	public boolean isRented () {
		return isRented;
	}
	public double getValue () {
		return value;
	}
	public Customer getCustomer() {
		return customer;
	}
	
	//equals Methode, wenn zwei Objekte gleich sind, ist die ID gleich
	public boolean equals(Object x) {
		if (x instanceof Rentable) {
			Rentable other = (Rentable) x;
			return this.id == other.id;
		}
		return false;
	}
	
	public int hashCode () {
		return id;
	}
}