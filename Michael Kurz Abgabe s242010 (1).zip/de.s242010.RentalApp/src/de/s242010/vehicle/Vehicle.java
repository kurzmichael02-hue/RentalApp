package de.s242010.vehicle;
import de.s242010.customer.Customer;


public class Vehicle extends Rentable {
	private final String vin; //Fahrzeug ID-Nummer
	private String licensePlate;
	private int mileage;
	private String manufacturer;
	private String fuelType; //Benzin, Diesel, Gas
	private String model;
	private int power; //PS
	private int countCylinders;
	private Customer currentCustomer;

	
	public Vehicle(double value, String description, String vin, String licensePlate, int mileage, String manufacturer, String model, String fuelType, int power, int countCylinders) 
	{
		super(description, value);
		this.vin = vin;
		this.licensePlate = licensePlate;
			this.fuelType = fuelType;
		this.mileage = mileage;
		this.manufacturer = manufacturer;
			this.countCylinders = countCylinders;
		this.model = model;
		this.power = power;
	}
	
	
	
	public void setCurrentCustomer(Customer c) {
	    this.currentCustomer = c;
	}

	public Customer getCurrentCustomer() {
	    return this.currentCustomer;
	}

	
		public String getVin () {
		return vin;
	}
	public int getcountCylinders() {
		return countCylinders;
	}
	public String getFuelType() {
		return fuelType;
	}
	public String getLicensePlate() {
		return licensePlate;
	}
	public int getMileage () {
		return mileage;
	}
	public String getManufacturer () {
		return manufacturer;
	}
	public String getModel () {
		return model;
	}
	public int getPower () {
		return power;
	}

	
	
	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}
	public void setFuelType( String fuelType) {
		this.fuelType = fuelType;
	}
	public void setCountCylinders (int countCylinders) {
		this.countCylinders = countCylinders;
	}
	public void setMileage(int mileage) {
		this.mileage = mileage;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setPower (int power) {
		this.power = power;
	}
	
	public String toString() {
	    return super.toString() + "\n" +
	           "VIN: " + vin + "\n" +
	           "Hersteller: " + manufacturer + "\n" +
	           "Modell: " + model + "\n" +
	           "Kennzeichen: " + licensePlate + "\n" +
	           "Kilometerstand: " + mileage + " km\n" +
	           "Leistung: " + power + " PS\n" +
	           "Kraftstoff: " + fuelType + "\n" +
	           "Zylinder: " + countCylinders;
	}

}