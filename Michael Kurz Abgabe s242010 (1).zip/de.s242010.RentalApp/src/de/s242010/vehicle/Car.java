package de.s242010.vehicle;

public class Car extends Vehicle 
{
	public Car(double value, String description, String vin, String licensePlate, int mileage, String manufacturer, String model,
	           String fuelType, int power, int countCylinders)
	{
		super(value, description, vin, licensePlate, mileage, manufacturer, model, fuelType, power, countCylinders);
	}

	public String toString() {
	    return "Fahrzeugtyp: Auto\n" +
	           "VIN: " + getVin() + "\n" +
	           "Hersteller: " + getManufacturer() + "\n" +
	           "Modell: " + getModel() + "\n" +
	           "Leistung: " + getPower() + " PS\n" +
	           "Zylinder: " + getcountCylinders() + "\n" +
	           "Kraftstoff: " + getFuelType() + "\n" +
	           "Kennzeichen: " + getLicensePlate() + "\n" +
	           "Kilometerstand: " + getMileage() + "\n" +
	           "Wert: " + getValue() + " Euro\n" +
	           "Verliehen: " + isRented();
	}

}