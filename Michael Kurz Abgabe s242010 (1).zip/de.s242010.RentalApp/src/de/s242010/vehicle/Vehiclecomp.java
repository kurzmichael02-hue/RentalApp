package de.s242010.vehicle;

import java.util.Comparator;


public class Vehiclecomp implements Comparator<Rentable> {
	public int compare(Rentable a, Rentable b) {
		return Double.compare(a.getValue(), b.getValue());
	}
}