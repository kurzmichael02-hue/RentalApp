package de.s242010.vehicle;
import java.util.Comparator;

public class VehicleMileageComp implements Comparator<Rentable> {
    
	public int compare(Rentable a, Rentable b) {
        
		if (a instanceof Vehicle && b instanceof Vehicle) {
            return Integer.compare(((Vehicle) a).getMileage(), ((Vehicle) b).getMileage());

 }
        return 0;
    }
}
