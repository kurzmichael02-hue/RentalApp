package de.s242010.RentalApp;

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import de.s242010.vehicle.Rentable;
import de.s242010.vehicle.Vehicle;
import de.s242010.customer.Customer;
import de.s242010.vehicle.Car;
import de.s242010.vehicle.ElectricCar;
import de.s242010.vehicle.Motorcycle;


import de.s242010.vehicle.Vehiclecomp;
import de.s242010.vehicle.Vehiclemanucomp;
import de.s242010.vehicle.VehicleMileageComp;
import de.s242010.vehicle.VehicleRentalStatusComp;

public class RentalApp {

	private static final String ADMIN_PASSWORD = "secret";
	private static final String ADMIN_USER = "admin";
	
	private static boolean isAdmin = false;
	
	private static ArrayList<Rentable> fahrzeuge = new ArrayList<Rentable>(); //Liste für alle Fahrzeuge
	private static ArrayList<Customer> kunden = new ArrayList<Customer>(); //Liste für alle Kunden

	 
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Willkommen bei der RentalApp!");
		
		//Login
		System.out.print("Benutzername: ");
		String username = scanner.nextLine();
		
		System.out.print("Passwort: ");
		String password = scanner.nextLine();
		
		if (username.equals(ADMIN_USER) && password.equals(ADMIN_PASSWORD)) {
			isAdmin = true;
			System.out.println("Login erfolgreich. Bist im Admin-Modus.\n");
		} else {
			System.out.println("Login erfolgreich. Bist im Benutzer-Modus.\n");
		}

		
		if (fahrzeuge.isEmpty()) {
		    ladeTestfahrzeuge();
		}
		if (kunden.isEmpty()) {
		    ladeTestkunden();
		}

		
		
		//Hauptmenü
		boolean running = true;
		while (running) {
			printMenu();
			
			System.out.print("Ihre Wahl: ");
			String choice = scanner.nextLine();
			
			switch (choice) {
		    case "1":
		        zeigeFahrzeuge();
		        break;

		    case "2":
		        zeigeKunden();
		        break;

		    case "3":
		        if (isAdmin) {
		            fahrzeugAnlegen(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "4":
		        if (isAdmin) {
		            kundenAnlegen(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "5":
		        if (isAdmin) {
		            fahrzeugAendern(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "6":
		        if (isAdmin) {
		            fahrzeugLoeschen(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "7":
		        if (isAdmin) {
		            kundenAendern(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "8":
		        if (isAdmin) {
		            ladeTestkunden(); 
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "9":
		        if (isAdmin) {
		            ladeTestfahrzeuge(); 
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "10":
		        if (isAdmin) {
		            kundenLoeschen(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "11":
		        if (isAdmin) {
		            fahrzeugSuchen(scanner); 
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "12":
		        fahrzeugeSortiertAnzeigen(scanner);
		        break;

		    case "13":
		        zeigeAusgelieheneFahrzeuge();
		        break;

		    case "14":
		        if (isAdmin) {
		            fahrzeugAusleihen(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "15":
		    	
		        if (isAdmin) {
		            fahrzeugZurueckgabe(scanner);
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;

		    case "16":
		        if (isAdmin) {
		            exportierteFahrzeuge();
		        } else {
		            System.out.println("Keine Berechtigung!\n");
		        }
		        break;


		    case "0":
		        System.out.println("Programm wird beendet.");
		        running = false;
		        break;

		    default:
		        System.out.println("Ungültige Eingabe.\n");
		        break;
		}

		}
		scanner.close();
		
	}
	
		private static void printMenu() {
		    System.out.println("====== Menü ======");

		    if (!isAdmin) {
		        System.out.println("1. - Fahrzeuge anzeigen");
		        System.out.println("2. - Kunden anzeigen");
		        System.out.println("12. - Fahrzeuge sortiert anzeigen");
		        System.out.println("13. - Ausgeliehene Fahrzeuge anzeigen (Reporting)");
		    } else {
		        System.out.println("1. - Fahrzeuge anzeigen");
		        System.out.println("2. - Kunden anzeigen");
		        System.out.println("3. - Fahrzeuge anlegen");
		        System.out.println("4. - Kunden anlegen");
		        System.out.println("5. - Fahrzeug ändern");
		        System.out.println("6. - Fahrzeug löschen");
		        System.out.println("7. - Kunde ändern");
		        System.out.println("8. - Testkunden laden");
		        System.out.println("9. - Testfahrzeuge laden");
		        System.out.println("10. - Kunde löschen");
		        System.out.println("11. - Fahrzeug suchen");
		        System.out.println("12. - Fahrzeuge sortiert anzeigen");
		        System.out.println("13. - Ausgeliehene Fahrzeuge anzeigen (Reporting)");
		        System.out.println("14. - Fahrzeug ausleihen");
		        System.out.println("15. - Fahrzeug zurückgeben");
		        System.out.println("16. - Fahrzeuge in Datei exportieren");
		    }

		    System.out.println("0. - Beenden");
		    System.out.println("=====================");
		}

	
	public static void zeigeFahrzeuge() {
		if (fahrzeuge.size() == 0) {
			System.out.println("Keine fahrzeuge vorhanden.\n");
		} else {
			System.out.println("Liste aller Fahrzeuge:\n");
			for (int i = 0; i < fahrzeuge.size(); i++) {
				Rentable ka = (Rentable) fahrzeuge.get(i);
				System.out.println(ka);
				System.out.println("--------------");
			}
		}
	}
	
	public static void ladeTestfahrzeuge() {
	    System.out.println("Fahrzeuge werden geladen...");

	    int vorher = fahrzeuge.size();

	    // Konventionelle Autos
	    addFahrzeugIfNotExists(new Car(12500.0, "Kompaktklasse", "VIN1001", "HD-XY123", 47000, "Volkswagen", "Golf VII", "Benzin", 110, 4));
	    addFahrzeugIfNotExists(new Car(17900.0, "Mittelklasse", "VIN1002", "MA-AB456", 32000, "BMW", "320d", "Diesel", 150, 4));
	    addFahrzeugIfNotExists(new Car(9800.0, "Kleinwagen", "VIN1003", "KA-QR789", 61000, "Ford", "Fiesta", "Benzin", 95, 3));
	    addFahrzeugIfNotExists(new Car(20400.0, "SUV", "VIN1004", "HN-ZX321", 21000, "Toyota", "RAV4", "Hybrid", 160, 4));

	    // Elektroautos
	    addFahrzeugIfNotExists(new ElectricCar(29900.0, "E-Limousine", "VIN2001", "B-EV100", 15000, "Tesla", "Model 3", "Elektro", 200, 0, 75.0, 120.0));
	    addFahrzeugIfNotExists(new ElectricCar(31000.0, "Stadtflitzer", "VIN2002", "M-EV200", 8000, "Renault", "Zoe", "Elektro", 110, 0, 52.0, 50.0));
	    addFahrzeugIfNotExists(new ElectricCar(45000.0, "Familienvan", "VIN2003", "F-EV300", 22000, "Volkswagen", "ID. Buzz", "Elektro", 150, 0, 77.0, 170.0));
	    addFahrzeugIfNotExists(new ElectricCar(39000.0, "Sportlich", "VIN2004", "S-EV400", 18000, "Audi", "e-tron", "Elektro", 180, 0, 95.0, 150.0));

	    // Motorräder
	    addFahrzeugIfNotExists(new Motorcycle(6500.0, "Sportlich", "VIN3001", "HD-MC1", 5000, "Kawasaki", "Ninja 400", "Benzin", 45, 2, "Sport", 5.2));
	    addFahrzeugIfNotExists(new Motorcycle(7200.0, "Cruiser", "VIN3002", "B-MC2", 7000, "Harley-Davidson", "Iron 883", "Benzin", 50, 2, "Cruiser", 6.5));
	    addFahrzeugIfNotExists(new Motorcycle(8100.0, "Naked Bike", "VIN3003", "M-MC3", 3000, "Yamaha", "MT-07", "Benzin", 55, 2, "Naked", 4.8));
	    addFahrzeugIfNotExists(new Motorcycle(9100.0, "Tourer", "VIN3004", "K-MC4", 12000, "BMW", "R 1250 RT", "Benzin", 70, 2, "Tourer", 4.6));

	    int nachher = fahrzeuge.size();
	    int geladen = nachher - vorher;

	    if (geladen > 0) {
	        System.out.println(geladen + " neue Fahrzeuge wurden erfolgreich geladen.\n");
	    } else {
	        System.out.println("Alle Testfahrzeuge sind bereits im System.\n");
	    }
	}

	private static void addFahrzeugIfNotExists(Vehicle neu) {
	    for (Rentable r : fahrzeuge) {
	        if (r instanceof Vehicle) {
	            if (((Vehicle) r).getVin().equals(neu.getVin())) {
	                return; // VIN bereits vorhanden
	            }
	        }
	    }
	    fahrzeuge.add(neu);
	}

	
	public static void ladeTestkunden() {
	    System.out.println("Kunden werden geladen...");

	    int vorher = kunden.size();

	    addKundeIfNotExists(new Customer("Johannes Bauer", "Bahnhofstraße 12", "90402", "Nürnberg", "Deutschland", "j.bauer@mail.de"));
	    addKundeIfNotExists(new Customer("Miriam Scholz", "Berliner Allee 88", "40212", "Düsseldorf", "Deutschland", "m.scholz@web.de"));
	    addKundeIfNotExists(new Customer("Tobias Weber", "Hauptstraße 3", "04109", "Leipzig", "Deutschland", "t.weber@gmx.de"));
	    addKundeIfNotExists(new Customer("Elif Yildiz", "Goethestraße 5", "60313", "Frankfurt am Main", "Deutschland", "elif.yildiz@t-online.de"));

	    int nachher = kunden.size();
	    int geladen = nachher - vorher;

	    if (geladen > 0) {
	        System.out.println(geladen + " neue Kunden wurden erfolgreich geladen.\n");
	    } else {
	        System.out.println("Alle Testkunden sind bereits im System.\n");
	    }
	}

	private static void addKundeIfNotExists(Customer neuerKunde) {
	    for (Customer k : kunden) {
	        if (k.getName().equals(neuerKunde.getName())){
	            return; 
	        }
	    }
	    kunden.add(neuerKunde);
	}


	
	
	public static void zeigeKunden() {
		if (kunden.size() == 0 ) {
			System.out.println("Keine Kunden vorhanden.\n");
		} else {
			System.out.println("Liste aller Kunden:\n");
			for (int i = 0; i < kunden.size(); i++) {
				Customer kunde = (Customer) kunden.get(i);
				System.out.println(kunde);
				System.out.println("----------------");
			}
		}
	}
	
			private static void fahrzeugAnlegen(Scanner scanner) {
			    System.out.println("Fahrzeugtyp wählen:");
			    System.out.println("1 - Auto");
			    System.out.println("2 - Elektroauto");
			    System.out.println("3 - Motorrad");
			    System.out.print("Ihre Wahl: ");
			    String typ = scanner.nextLine();

			    System.out.print("Beschreibung: ");
			    String beschreibung = scanner.nextLine();

			    System.out.print("Wert (€): ");
			    double wert = scanner.nextDouble();
			    scanner.nextLine();

			    System.out.print("VIN: ");
			    String vin = scanner.nextLine();

			    // VIN prüfen
			    for (int i = 0; i < fahrzeuge.size(); i++) {
			        Object o = fahrzeuge.get(i);
			        if (o instanceof Vehicle) {
			            Vehicle v = (Vehicle) o;
			            if (v.getVin().equals(vin)) {
			                System.out.println("Fehler: Fahrzeug mit dieser VIN existiert bereits.");
			                return;
			            }
			        }
			    }

			    System.out.print("Kennzeichen: ");
			    String kennzeichen = scanner.nextLine();

			    System.out.print("Kilometerstand: ");
			    int km = scanner.nextInt();
			    scanner.nextLine();

			    System.out.print("Hersteller: ");
			    String hersteller = scanner.nextLine();

			    System.out.print("Modell: ");
			    String modell = scanner.nextLine();

			    System.out.print("Leistung (PS): ");
			    int ps = scanner.nextInt();
			    scanner.nextLine();

			    System.out.print("Kraftstoffart: ");
			    String kraftstoff = scanner.nextLine();

			    System.out.print("Zylinderanzahl: ");
			    int zylinder = scanner.nextInt();
			    scanner.nextLine();

			    if (typ.equals("1")) {
			        fahrzeuge.add(new Car(wert, beschreibung, vin, kennzeichen, km, hersteller, modell, kraftstoff, ps, zylinder));
			        System.out.println("Auto erfolgreich angelegt.\n");

			    } else if (typ.equals("2")) {
			        System.out.print("Batteriekapazität (kWh): ");
			        double batterie = scanner.nextDouble();
			        scanner.nextLine();

			        System.out.print("Ladeleistung (kW): ");
			        double ladeleistung = scanner.nextDouble();
			        scanner.nextLine();

			        fahrzeuge.add(new ElectricCar(wert, beschreibung, vin, kennzeichen, km, hersteller, modell, kraftstoff, ps, zylinder, batterie, ladeleistung));
			        System.out.println("Elektroauto erfolgreich angelegt.\n");

			    } else if (typ.equals("3")) {
			        System.out.print("Typ (Roller/Cruiser/...): ");
			        String typMotorrad = scanner.nextLine();

			        System.out.print("Beschleunigung (0–100 km/h in Sekunden): ");
			        double boost = scanner.nextDouble();
			        scanner.nextLine();

			        fahrzeuge.add(new Motorcycle(wert, beschreibung, vin, kennzeichen, km, hersteller, modell, kraftstoff, ps, zylinder, typMotorrad, boost));
			        System.out.println("Motorrad erfolgreich angelegt.\n");

			    } else {
			        System.out.println("Ungültige Eingabe. Abbruch.\n");
			    }
			}


	
	private static void kundenAnlegen(Scanner scanner) {
		System.out.println("neuen Kunden anlegen: ");
		
		System.out.print("Name: ");
		String name = scanner.nextLine();
		
		//Prüfe ob gleicher Name bereits exisitiert
		for (int i = 0; i < kunden.size(); i++) {
			Customer c = kunden.get(i);
			if (c.getName().equals(name)) {
				System.out.println("Ein Kunde mit diesem Namen existiert bereits.\n");
				return;
			}
		}
		
		System.out.print("Straße: ");
		String street = scanner.nextLine();
		
		System.out.print("PLZ: ");
	String plz = scanner.nextLine();
		
		System.out.print("Stadt: ");
		String city = scanner.nextLine();
		
		System.out.print("Land: ");
		String country = scanner.nextLine();
		
		System.out.print("E-Mail: ");
		String email = scanner.nextLine();
		
		kunden.add(new Customer(name, street, plz, city, country, email));
		System.out.println("Kunde erfolgreich angelegt.\n");
	}
	
	
	
	private static void fahrzeugAendern(Scanner scanner) {
		System.out.print("VIN des Fahrzeugs, das geändert werden soll: ");
		String vin = scanner.nextLine();
		
		for (int i = 0; i < fahrzeuge.size(); i++) {
			Rentable r = fahrzeuge.get(i);
			if (r instanceof Vehicle) {
				Vehicle v = (Vehicle) r;
				if (v.getVin().equals(vin)) {
					System.out.print("Neues Kennzeichen (alt: " + v.getLicensePlate() + "): ");
					String kennzeichen = scanner.nextLine();
					v.setLicensePlate(kennzeichen);
					
					System.out.print("neuer Kilometerstand (alt: " + v.getMileage() + "): ");
					int km = scanner.nextInt();
					scanner.nextLine();
					v.setMileage(km);
					
					System.out.print("neuer Hersteller (alt: " + v.getMileage() + "): ");
					String hersteller = scanner.nextLine();
					v.setManufacturer(hersteller);
					
					System.out.print("Neues Modell (alt: " + v.getModel() + "): ");
					String modell = scanner.nextLine();
					v.setModel(modell);
					
					System.out.print("Neues Kraftstoffart (alt: " + v.getFuelType() + "): ");
					String kraftstoff = scanner.nextLine();
					v.setFuelType(kraftstoff);
					
					System.out.print("Neue Leistung (PS) (alt: " +v.getPower() + "): ");
				int ps = scanner.nextInt();
					scanner.nextLine();
					v.setPower(ps);
					
					System.out.print("Neue Zylinderanzahl (alt: " + v.getcountCylinders() + "): ");
					int zylinder = scanner.nextInt();
					scanner.nextLine();
					v.setCountCylinders(zylinder);

					System.out.println("Fahrzeug wurde aktualisiert.\n");
					return;
				}
			}
		}
		System.out.println("Fahrzeug mit VIN " + vin + " nicht gefunden.\n");
	}
	
	
	private static void fahrzeugLoeschen(Scanner scanner) {
		System.out.print("VIN des Fahrzeugs, das gelöscht werden soll: ");
		String vin = scanner.nextLine();
		
		for (int i = 0; i < fahrzeuge.size(); i++) {
			Rentable r = fahrzeuge.get(i);
			if (r instanceof Vehicle) {
				Vehicle v = (Vehicle) r;
				if (v.getVin().equals(vin)) {
					fahrzeuge.remove(i);
					System.out.println("Fahrzeug wurde gelöscht.\n");
					return;
				}
			}
		}
		System.out.println("Fahrzeug mit VIN " + vin + " nicht gefunden.\n");
	}
	
	
	
	private static void kundenAendern(Scanner scanner) {
		System.out.print("Name des Kunden, der geändert werden soll: ");
		String name = scanner.nextLine();
		
		for (int i = 0; i < kunden.size(); i++) {
			Customer k = kunden.get(i);
			if (k.getName().equals(name)) {
				System.out.print("Neue Straße (alt: " + k.getStreet() + "): ");
				String street = scanner.nextLine();
				k.setStreet(street);
				
				System.out.print("Neue PLZ (alt: " + k.getZipcode() + "): ");
				String plz = scanner.nextLine();
				k.setZipcode(plz);
				
				System.out.print("Neue Stadt (alt: " + k.getCity() + "): ");
				String city = scanner.nextLine();
				k.setCity(city);
				
				System.out.print("Neue Land (alt: " + k.getCountry() + "): ");
				String land = scanner.nextLine();
				k.setCountry(land);
				
				System.out.print("Neue E-Mail (alt: " + k.getEmail() + "): ");
	            String email = scanner.nextLine();
	            k.setEmail(email);

	            System.out.println("Kunde wurde aktualisiert.\n");
	            return;
			}
		}
		System.out.println("Kunde mit Name \"" + name + "\" nicht gefunden.\n");
	}
	
	private static void kundenLoeschen(Scanner scanner) {
		System.out.print("Name des Kunden, der gelöscht werden soll: ");
		String name = scanner.nextLine();
		
		for (int i = 0; i < kunden.size(); i++) {
			Customer k = kunden.get(i);
			if (k.getName().equals(name)) {
				kunden.remove(i);
				System.out.println("Kunde wurde gelöscht.\n");
				return;
			}
			
		
}	
		System.out.println("Kunde mit Name \"" + name + "\" nicht gefunden.\n");
	}
	
	
	private static void fahrzeugSuchen(Scanner scanner) {
		System.out.print("Nach welcher VIN soll gesucht werden? ");
		String vin = scanner.nextLine();

		for (int i = 0; i < fahrzeuge.size(); i++) {
			Rentable r = fahrzeuge.get(i);
			if (r instanceof Vehicle) {
				Vehicle v = (Vehicle) r;
				if (v.getVin().equals(vin)) {
					System.out.println("Fahrzeug gefunden:");
					System.out.println(v);
					return;
				}
			}
		}
		System.out.println("Kein Fahrzeug mit dieser VIN gefunden.\n");
	}

	
	private static void fahrzeugAusleihen(Scanner scanner) {
		System.out.print("VIN des Fahrzeugs: ");
		String vin = scanner.nextLine();
		
		System.out.print("Name des Kunden: ");
		String kundenname = scanner.nextLine();
		
		Vehicle fahrzeug = null;
		Customer kunde = null;
		
		for (int i = 0; i < fahrzeuge.size(); i++) {
			Object o = fahrzeuge.get(i);
			if (o instanceof Vehicle) {
				Vehicle v = (Vehicle) o;
				if (v.getVin().equals(vin)) {
					fahrzeug = v;
					break;
	}
			
			}
		}
		
		if (fahrzeug == null) {
			System.out.println("Fahrzeug nicht gefunden.\n");
			return;
		}
		
		if (fahrzeug.isRented() ) {
			System.out.println("Fahrzeug ist bereits ausgeliehen.\n");
			return;
		}
		
		for (int i = 0; i < kunden.size(); i++) {
			Customer k = kunden.get(i);
			if (k.getName().equals(kundenname)) {
				kunde = k;
				break;
			}
			}
		
		if (kunde == null) {
			System.out.println("Kunde nicht gefunden.\n");
			return;
		}
		
		fahrzeug.setRented(true);
		fahrzeug.setCurrentCustomer(kunde);
		System.out.println("fahrzeug wurde erfolgreich ausgeliegen.\n");
	}
	
	private static void fahrzeugZurueckgabe(Scanner scanner) {
		System.out.print("ViN des zurückgegebenen Fahrzeugs: ");
		String vin = scanner.nextLine();
		
		for (int i = 0; i < fahrzeuge.size(); i++) {
			Object o = fahrzeuge.get(i);
					if (o instanceof Vehicle) {
						Vehicle v = (Vehicle) o;
						if (v.getVin().equals(vin)) {
			if (!v.isRented()) {
								System.out.println("Fahrzeug ist nicht ausgeliehen.\n");
								return;
							}
		v.setRented(false);
							v.setCurrentCustomer(null);
							System.out.println("Fahrzeug wurde erfolgreich zurückgegeben.\n");
							return;
						}
					}
		}
		System.out.println("Fahrzeug nicht gefunden.\n");
	}
	
	
	
	
	private static void fahrzeugeSortiertAnzeigen(Scanner scanner) {
		System.out.println("Nach welchem Kriterium sortieren?");
		System.out.println("1. - Wert");
		System.out.println("2. - Hersteller");
		System.out.println("3. - Kilometerstand");
		System.out.println("4. - Verleihstatus");
		System.out.print("Ihre Wahl: ");
		String eingabe = scanner.nextLine();
		
		if (fahrzeuge.isEmpty()) {
			System.out.println("Keine Fahrzeuge vorhanden.\n");
			return;
		}
		
		ArrayList<Rentable> sortierteListe = new ArrayList<Rentable>(fahrzeuge);
		
		if (eingabe.equals("1")) {
			sortierteListe.sort(new Vehiclecomp());
		} else if (eingabe.equals("2")) {
	sortierteListe.sort(new Vehiclemanucomp());
		} else if (eingabe.equals("3")) {
			sortierteListe.sort(new VehicleMileageComp());
		} else if (eingabe.equals("4")) {
			sortierteListe.sort(new VehicleRentalStatusComp());
		} else {
			System.out.println("Ungültige Auswahl.\n");
			return;
		}
		System.out.println("Sortierte Liste:\n");
		for (int i = 0; i < sortierteListe.size(); i++) {
			System.out.println(sortierteListe.get(i));
			System.out.println("-----------");
		}
	}
	
	
	private static void zeigeAusgelieheneFahrzeuge() {
		  System.out.println("Aktuell ausgeliehene Fahrzeuge:\n");
		  
		  boolean gefunden = false;
		  for (int i = 0; i < fahrzeuge.size(); i++) {
			  Rentable r = fahrzeuge.get(i);
				  if (r instanceof Vehicle) {
					  Vehicle v = (Vehicle) r;
				if (v.isRented()) {
					System.out.println(v);
					System.out.println("Ausgeliehen von:\n" + v.getCurrentCustomer());
					System.out.println("--------------");
					gefunden = true;
				}
				  }
			  }
			  if (!gefunden) {
				  System.out.println("KEeine Fahrzeuge sind derzeit ausgeliehen.\n");
			  }
		  }
	
	
	private static void exportierteFahrzeuge() {
		try {
			Path ordner = Path.of("export");
			
			if (!Files.exists(ordner)) {
				Files.createDirectory(ordner);
			}
			
			Path datei = Path.of(ordner.toString(), "export.txt");
			PrintWriter writer = new PrintWriter(datei.toString());
			
			
			
			for (int i = 0; i < fahrzeuge.size(); i++) {
				Rentable r = fahrzeuge.get(i);
				writer.println(r.toString());
				writer.println("-----------------");
			}
			
			writer.close();
			System.out.println("Fahrzeuge wurden erfolgreich exportiert nach " + datei + "\n");
			
		} catch (IOException e) {
			System.out.println("Fehler beim Export: Datei konnte nicht geschrieben werden.\n");
		}
					}

	}